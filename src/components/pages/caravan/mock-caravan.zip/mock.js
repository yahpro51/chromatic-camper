export const caravans= [
    { 
        name: "Adventure Compact", 
        company: "Seoul Caravans", 
        star_rate: 4.2, 
        cost_krw: 120000 },
    { 
        name: "Family Explorer", 
        company: "Han River Camping", 
        star_rate: 4.8, 
        cost_krw: 180000 },
    { 
        name: "Weekend Warrior", 
        company: "Busan Trail", 
        star_rate: 4.5, 
        cost_krw: 155000 },
    { 
        name: "Urban Camper", 
        company: "Jeju Caravan Rentals", 
        star_rate: 4.1, 
        cost_krw: 110000 },
    { 
        name: "Coastal Cruiser", 
        company: "Seaside Caravans", 
        star_rate: 4.9, 
        cost_krw: 200000 },
    { 
        name: "Deluxe Retreat", 
        company: "Gangnam Camping", 
        star_rate: 4.7, 
        cost_krw: 170000 },
    { 
        name: "Mountain Explorer", 
        company: "Daegu Ventures", 
        star_rate: 4.3, 
        cost_krw: 145000 },
    { 
        name: "Sunset Haven", 
        company: "Gyeonggi Nomads", 
        star_rate: 4.6, 
        cost_krw: 160000 },
    { 
        name: "Forest Dweller", 
        company: "Seoul Caravans", 
        star_rate: 4.4, 
        cost_krw: 140000 },
    { 
        name: "Grand Journey", 
        company: "Han River Camping", 
        star_rate: 4.8, 
        cost_krw: 190000 },
    { 
        name: "Luxury Escape", 
        company: "Busan Trail", 
        star_rate: 4.9, 
        cost_krw: 210000 },
    { 
        name: "Compact Adventure", 
        company: "Jeju Caravan Rentals", 
        star_rate: 4.0, 
        cost_krw: 100000 },
    { 
        name: "Nomad Lite", 
        company: "Seaside Caravans", 
        star_rate: 3.9, 
        cost_krw: 95000 },
    { 
        name: "Peak Comfort", 
        company: "Gangnam Camping", 
        star_rate: 4.6, 
        cost_krw: 175000 },
    { 
        name: "Seaside Suite", 
        company: "Daegu Ventures", 
        star_rate: 4.5, 
        cost_krw: 165000 },
    { 
        name: "Voyager XL", 
        company: "Gyeonggi Nomads", 
        star_rate: 4.7, 
        cost_krw: 185000 },
    { 
        name: "Alpine Trek", 
        company: "Seoul Caravans", 
        star_rate: 4.1, 
        cost_krw: 135000 },
    { 
        name: "Desert Oasis", 
        company: "Han River Camping", 
        star_rate: 4.2, 
        cost_krw: 145000 },
    { 
        name: "Trail Master", 
        company: "Busan Trail", 
        star_rate: 4.6, 
        cost_krw: 170000 },
    { 
        name: "Green Valley", 
        company: "Jeju Caravan Rentals", 
        star_rate: 4.4, 
        cost_krw: 150000 },
    { 
        name: "Riverfront Delight", 
        company: "Seaside Caravans", 
        star_rate: 4.8, 
        cost_krw: 190000 },
    { 
        name: "Pioneer Classic", 
        company: "Gangnam Camping", 
        star_rate: 4.0, 
        cost_krw: 120000 },
    { 
        name: "Summit Suite", 
        company: "Daegu Ventures", 
        star_rate: 4.7, 
        cost_krw: 180000 },
    { 
        name: "Wilderness Escape", 
        company: "Gyeonggi Nomads", 
        star_rate: 4.5, 
        cost_krw: 160000 },
    { 
        name: "Snowy Cabin", 
        company: "Seoul Caravans", 
        star_rate: 4.3, 
        cost_krw: 140000 },
    { 
        name: "Open Road", 
        company: "Han River Camping", 
        star_rate: 4.1, 
        cost_krw: 130000 },
    { 
        name: "Beachfront Bliss", 
        company: "Busan Trail", 
        star_rate: 4.9, 
        cost_krw: 210000 },
    { 
        name: "Glamping Getaway", 
        company: "Jeju Caravan Rentals", 
        star_rate: 4.5, 
        cost_krw: 160000 },
    { 
        name: "Peak Adventure", 
        company: "Seaside Caravans", 
        star_rate: 4.6, 
        cost_krw: 175000 },
    { 
        name: "Explorer's Haven", 
        company: "Gangnam Camping", 
        star_rate: 4.4, 
        cost_krw: 150000 },
    { 
        name: "Tranquil Trails", 
        company: "Daegu Ventures", 
        star_rate: 4.2, 
        cost_krw: 145000 },
    { 
        name: "Nature's Path", 
        company: "Gyeonggi Nomads", 
        star_rate: 4.7, 
        cost_krw: 185000 },
    { 
        name: "Starry Nights", 
        company: "Seoul Caravans", 
        star_rate: 4.9, 
        cost_krw: 200000 },
    { 
        name: "Riverside Retreat", 
        company: "Han River Camping", 
        star_rate: 4.3, 
        cost_krw: 140000 },
    { 
        name: "Twilight Trekker", 
        company: "Busan Trail", 
        star_rate: 4.6, 
        cost_krw: 175000 },
    { 
        name: "Urban Nomad", 
        company: "Jeju Caravan Rentals", 
        star_rate: 4.1, 
        cost_krw: 115000 },
    { 
        name: "Mountain Mirage", 
        company: "Seaside Caravans", 
        star_rate: 4.8, 
        cost_krw: 190000 },
    { 
        name: "Coastal Comfort", 
        company: "Gangnam Camping", 
        star_rate: 4.2, 
        cost_krw: 145000 },
    { 
        name: "Great Escape", 
        company: "Daegu Ventures", 
        star_rate: 4.7, 
        cost_krw: 180000 },
    { 
        name: "Sunset Voyager", 
        company: "Gyeonggi Nomads", 
        star_rate: 4.5, 
        cost_krw: 165000 }
]
